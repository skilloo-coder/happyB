VERSION OF SOFTWARE

  PHP--- 8.2.12 / PHP 8.2.12
xampp-windows-x64-8.2.12-0-VS16-installer.exe


RUNNING STEPS----

To set up a database connection with PHP for your project, follow these steps:

1. Set Up Your Environment

Install PHP: Download and install PHP from the official PHP website.

Install MySQL: Make sure MySQL is installed, and that you have access to it (you can download it from MySQL’s official website).

Set Up a Local Server: Use a local server environment like XAMPP or WAMP to run PHP and MySQL together.

XAMPP: Download XAMPP

WAMP: Download WAMP


Start the Server: After installing XAMPP or WAMP, start the server services for Apache and MySQL.


2. Create the Database and Tables in MySQL

Open phpMyAdmin (usually accessible at http://localhost/phpmyadmin).

Run the following SQL to create the database and tables, if not already created:

CREATE DATABASE IF NOT EXISTS student_db;
USE student_db;


3. Configure Database Connection in PHP

Create a config.php file to store the database connection information. Place this file in your project directory (for example, htdocs/YourProject if using XAMPP).



4. Create Registration and Login Pages

register.php: Create a registration page to insert user details into the database.



5. Create Welcome and Logout Pages

welcome.php: A welcome page that only authenticated users can access.


logout.php: Destroy the session and redirect to the login page.




6. Place Files in the Web Server Directory

Copy all .php files (config.php, register.php, login.php, welcome.php, and logout.php) into your web server directory (e.g., C:\xampp\htdocs\YourProject if using XAMPP).


7. Run the Application

Start Apache and MySQL from your server control panel (e.g., XAMPP Control Panel).

Open a browser and go to:

http://localhost/YourProject/register.php to register a new user.

http://localhost/YourProject/login.php to log in.

After successful login, you should be redirected to welcome.php, where you can see a personalized welcome message.



   