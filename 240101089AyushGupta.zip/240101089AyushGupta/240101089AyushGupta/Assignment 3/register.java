<!DOCTYPE html>
<html lang="en">
<head><title>Register</title></head>
<body>
    <form action="../register" method="POST">
        <label>Roll Number:</label><input type="text" name="roll_number"><br>
        <label>User ID:</label><input type="text" name="user_id"><br>
        <label>Password:</label><input type="password" name="password"><br>
        <label>Name:</label><input type="text" name="name"><br>
        <label>Branch:</label><input type="text" name="branch"><br>
        <button type="submit">Register</button>
    </form>
</body>
</html>

